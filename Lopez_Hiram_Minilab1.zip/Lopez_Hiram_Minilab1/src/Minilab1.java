/************************************************
 *  CS 2401
 *
 *  MINILAB 1: Methods, Arrays, Loops
 *
 *  DUE: Sunday January 30
 *
 *  INSTRUCTIONS:
 *     Complete each of the methods described
 *     in the comments below.
 *
 *  GRADING RUBRIC:
 *  Each method is worth 25 points:
 *  - 5 points for a correct method signature
 *  - 10 points for a correct method body
 *  - 10 points for testing the method using JUnit
 *     - You need 5 tests case (2 pts per case)
 *     - The tests must be created in a separate
 *       file, called "Minilab1Tests.java"
 *       (We will go over JUnit during Lab)
 *
 ***********************************************/

public class Minilab1 {

    /* METHOD 1: reverse
       Takes: an Array of Integers
       Returns: an Array of Integers
       - This method creates a new array of integers,
         with the same elements as the input but
         in reverse order.
    */
    public static int[] reverse(int[] arr){
        int [] newArr = new int[arr.length];
        for(int i = arr.length - 1; i >= 0; i--){
            newArr[arr.length - i - 1] = arr[i];
        }
        return newArr;
    }

    /* METHOD 2: averageArray
       Takes: a rectangular 2D Array of Integers
       Returns: an Array of Doubles
       - This method computes the average of all columns
         in the input. For example, in the output,
         the element at position 0 is the average
         of all the elements at position 0 in each
         of the rows in the input.
    */
    public static double[] averageArray(int[][] arr){
        double[] avgArray = new double[arr[0].length];
        double sum, numOfColumns = (double)arr[0].length, colAvg = 0; //this because we know that is a rectangular array, so we have the same number of columns
        for (int i = 0; i < arr.length; i++){
            sum = 0;
            for (int j = 0; j < arr[i].length; j++){
                sum +=  arr[j][i];
                colAvg = (sum / numOfColumns);
            }
            avgArray[i] = colAvg;
        }
        return avgArray;
    }

    /* METHOD 3: rotateArray
       Takes:
         - an Array of Integers
         - a boolean
       Returns: an Array of Integers
       - This method takes an array of integers
         and rotates it, depending on the boolean value:
         If the boolean is true, rotate Clockwise;
         otherwise, rotate counterclockwise.
         For example, with array:
         3 4 5 7
         1 2 6 8
         8 9 0 3

        If we rotate Clockwise:
        8 1 3
        9 2 4
        0 6 5
        3 8 7

        Counterclockwise:
        7 8 3
        5 6 0
        4 2 9
        3 1 8
    */
   public static int[][] rotateArray(int[][] arr, boolean isClockWise){
        int[][] arrRot = new int[arr[0].length][arr.length];
        if(isClockWise){
            for (int i = 0; i < arrRot.length; i++){
                for (int j = 0; j< arrRot[i].length; j++){
                    arrRot[i][j] = arr[arr.length - 1 - j][i];
                }
            }
            return arrRot;
        }
       for (int i = 0; i < arrRot.length; i++){
           for (int j = 0; j< arrRot[i].length; j++){
               arrRot[i][j] = arr[j][arr[0].length - 1 -i];
           }
       }
       return arrRot;

    }

    /* METHOD 4: diagonalSum
       Takes: a square 2D Array of Integers
       Returns: an Array of Integers
       - This method adds the values in
         each of the diagonals and puts
         the values in an array of length 2,
         with the first element storing
         the sum starting at [0][0].
         For example, with input:
         1 3 2
         4 5 7
         6 9 8

         Produces the output
         14 13
    */
    public static int[] diagonalSum(int[][] arr){
        int sumDiag1 = 0, sumDiag2 = 0;
        for(int i = 0; i < arr.length; i++) {
            sumDiag1 += arr[i][i];
        }
        for (int i = 0; i < arr.length; i++) {
            sumDiag2 += arr[i][arr.length - 1 - i];
        }
        int[] sums = new int[]{sumDiag1, sumDiag2};
        return sums;
    }

}
