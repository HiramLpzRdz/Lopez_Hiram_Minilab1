import org.junit.Test;

import static org.junit.Assert.*;

public class Minilab1Tests {

    @Test
    public void reverseTest() {
        Minilab1 test1 = new Minilab1();
        int[] expectedArr = {5,4,3,2,1};
        int[] expectedArr2 = {10,9,8,7,6};
        int[] expectedArr3 = {15,14,13,12,11};
        int[] expectedArr4 = {20,19,18,17,16};
        int[] expectedArr5 = {25,24,23,22,21};
        assertArrayEquals(expectedArr, test1.reverse(new int[]{1,2,3,4,5}));
        assertArrayEquals(expectedArr2, test1.reverse(new int[]{6,7,8,9,10}));
        assertArrayEquals(expectedArr3, test1.reverse(new int[]{11,12,13,14,15}));
        assertArrayEquals(expectedArr4, test1.reverse(new int[]{16,17,18,19,20}));
        assertArrayEquals(expectedArr5, test1.reverse(new int[]{21,22,23,24,25}));
    }

    @Test
    public void averageArrayTest() {
        Minilab1 test1 = new Minilab1();
        int[][] arr = {{1,3,4},
                        {2,0,7},
                        {6,9,7}};
        double[] expected = {3, 4, 6};

        int[][] arr2 = {{3,5,6},
                {2,0,7},
                {6,9,7}};
        double[] expected2 = {3.6, 4.6, 6.6};

        int[][] arr3 = {{1,3,4},
                {3,5,9},
                {6,9,8}};
        double[] expected3 = {3.3, 5.6, 7};

        int[][] arr4 = {{1,3,4},
                {2,0,7},
                {9,11,15}};
        double[] expected4 = {4, 4.6, 8.6};

        int[][] arr5 = {{11,6,9},
                {2,0,7},
                {6,9,7}};
        double[] expected5 = {6.3, 5, 7.6};

        assertArrayEquals(expected, test1.averageArray(arr), .1);
        assertArrayEquals(expected2, test1.averageArray(arr2), .1);
        assertArrayEquals(expected3, test1.averageArray(arr3), .1);
        assertArrayEquals(expected4, test1.averageArray(arr4), .1);
        assertArrayEquals(expected5, test1.averageArray(arr5), .1);
    }

    @Test
    public void rotateArrayTest() {
        Minilab1 test1 = new Minilab1();
        int[][] arr = {{3,4,5,7},
                        {1,2,6,8},
                        {8,9,0,3}};
        int[][] expectedIfTrue  = {{8,1,3},
                                {9,2,4},
                                {0,6,5},
                                {3,8,7}};
        int[][] expectedIfFalse =  {{7,8,3},
                                    {5,6,0},
                                    {4,2,9},
                                    {3,1,8}};
        assertArrayEquals(expectedIfTrue, test1.rotateArray(arr,true));
        assertArrayEquals(expectedIfFalse, test1.rotateArray(arr,false));

        int[][] arr2 = {{3,4,5},
                        {1,2,6},
                        {8,9,0}};
        int[][] expectedIfTrue2  = {{8,1,3},
                                    {9,2,4},
                                    {0,6,5},};
        int[][] expectedIfFalse2 =  {{5,6,0},
                                    {4,2,9},
                                    {3,1,8}};
        assertArrayEquals(expectedIfTrue2, test1.rotateArray(arr2,true));
        assertArrayEquals(expectedIfFalse2, test1.rotateArray(arr2,false));

        int[][] arr3 = {{4,5,7},
                        {2,6,8},
                        {9,0,3}};
        int[][] expectedIfTrue3  = {{9,2,4},
                                    {0,6,5},
                                    {3,8,7}};
        int[][] expectedIfFalse3 =  {{7,8,3},
                                    {5,6,0},
                                    {4,2,9}};
        assertArrayEquals(expectedIfTrue3, test1.rotateArray(arr3,true));
        assertArrayEquals(expectedIfFalse3, test1.rotateArray(arr3,false));

        int[][] arr4 = {{1,2},
                        {3,4}};
        int[][] expectedIfTrue4  = {{3,1},
                                    {4,2}};
        int[][] expectedIfFalse4 =  {{2,4},
                                    {1,3}};
        assertArrayEquals(expectedIfTrue4, test1.rotateArray(arr4,true));
        assertArrayEquals(expectedIfFalse4, test1.rotateArray(arr4,false));

        int[][] arr5 = {{3,4},
                        {1,2}};
        int[][] expectedIfTrue5  = {{1,3},
                                    {2,4}};
        int[][] expectedIfFalse5 =  {{4,2},
                                    {3,1}};
        assertArrayEquals(expectedIfTrue5, test1.rotateArray(arr5,true));
        assertArrayEquals(expectedIfFalse5, test1.rotateArray(arr5,false));
    }

    @Test
    public void diagonalSumTest() {
        Minilab1 test1 = new Minilab1();
        int[][] arr = {{1,3,2},
                      {4,5,7},
                      {6,9,8}};
        int[] expected = {14, 13};

        int[][] arr2 = {{5,3,2},
                {4,5,7},
                {6,9,5}};
        int[] expected2 = {15, 13};

        int[][] arr3 = {{1,3,5},
                {4,5,7},
                {5,9,8}};
        int[] expected3 = {14, 15};

        int[][] arr4 = {{2,4,2},
                {4,5,2},
                {7,6,4}};
        int[] expected4 = {11, 14};

        int[][] arr5 = {{6,3,8},
                {3,7,8},
                {9,3,1}};
        int[] expected5 = {14, 24};

        assertArrayEquals(expected, test1.diagonalSum(arr));
        assertArrayEquals(expected2, test1.diagonalSum(arr2));
        assertArrayEquals(expected3, test1.diagonalSum(arr3));
        assertArrayEquals(expected4, test1.diagonalSum(arr4));
        assertArrayEquals(expected5, test1.diagonalSum(arr5));
    }



}